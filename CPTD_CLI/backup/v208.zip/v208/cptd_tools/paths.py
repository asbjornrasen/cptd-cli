from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
HISTORY_FILE = BASE_DIR / "history.txt"
SETTINGS_FILE = BASE_DIR / "settings.json"
